#ifndef __SAPI_DELAY_H__
#define __SAPI_DELAY_H__

#include <sapi_datatypes.h>

#ifdef __cplusplus
   extern "C" {
#endif

void delay( tick_t time );

#ifdef __cplusplus
   }
#endif

#endif // __SAPI_DELAY_H__
