#ifndef __SAPI_H__
#define __SAPI_H__

#include <sapi_datatypes.h>

#include <sapi_tick.h>
#include <sapi_gpio.h>
#include <sapi_uart.h>

#include <sapi_delay.h>

#ifdef __cplusplus
   extern "C" {
#endif

#ifdef __cplusplus
   }
#endif

#endif // __SAPI_H__
