#ifndef __SAPI_TICK_H__
#define __SAPI_TICK_H__

#include <sapi_datatypes.h>

#ifdef __cplusplus
   extern "C" {
#endif

void tickThread();

#ifdef __cplusplus
   }
#endif

#endif // __SAPI_TICK_H__
